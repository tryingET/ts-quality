import os, sys, time
r=sys.argv[1]
open(r+'/proxy-fixture/interruption-child-pid','w').write(str(os.getpid()))
time.sleep(120)
