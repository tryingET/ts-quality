import json, os, signal, socket, subprocess, sys, time
r=sys.argv[1]
log=r+'/proxy-fixture/policy.jsonl';port_path=r+'/proxy-fixture/port'
p=subprocess.Popen(['/usr/bin/python3',r+'/lean/registry-proxy.py',log,port_path],start_new_session=True)
results=[]
try:
 for _ in range(300):
  if os.path.exists(port_path):break
  time.sleep(.01)
 port=int(open(port_path).read())
 for line in ['CONNECT example.invalid:443 HTTP/1.1','CONNECT registry.npmjs.org:444 HTTP/1.1','GET https://registry.npmjs.org/ HTTP/1.1','CONNECT registry.npmjs.org:443.evil HTTP/1.1']:
  with socket.create_connection(('127.0.0.1',port),timeout=2) as s:
   s.sendall((line+'\r\n\r\n').encode());response=s.recv(256)
   results.append({'request':line,'rejected':response.startswith(b'HTTP/1.1 403')})
finally:
 os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=2)
try:
 socket.create_connection(('127.0.0.1',port),timeout=1)
 cleanup=False
except OSError:
 cleanup=True
receipt={'noNetworkSandbox':True,'rejectionCases':results,'ownedGroupCleanup':cleanup,'proxyExit':p.returncode}
open(r+'/receipts/proxy-policy-fixture-check.json','w').write(json.dumps(receipt,indent=2)+'\n')
assert cleanup and all(x['rejected'] for x in results)
