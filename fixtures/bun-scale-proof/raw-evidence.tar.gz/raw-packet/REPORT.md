# #6551 durability leaf — tested lean cold-cache recipe

## Deliverable

- Small durable recipe: `lean/`, also `lean-recipe.tar.gz` (no source archive, dependency cache, node_modules or old packet).
- Small actual evidence packet: `cold-raw-packet.tar.gz` (raw run/witness/LCOV/sidecars, exact config/support, command/env/source/integrity receipts, logs; no dependencies or full target source).
- Retain the separate ~176 KB CLI tarball with SHA-256 `6da7db1de4ca272346677740f20f2ab6c7a125bd96e40d58a5c52af9b77334ae`; supply the exact Git archive on each replay.
- Inputs/requirements/Git archive command: `lean/inputs.json` and `lean/README.md`.

Final exact recipe bytes were executed from an empty cache and initially empty owned HOME in:

`/home/tryinget/.local/state/pi-quests/tmp/task6551-lean-cold-D7lynoEC`

Raw run:

`/home/tryinget/.local/state/pi-quests/tmp/task6551-lean-cold-D7lynoEC/target/.ts-quality/runs/task6551-lean-cold-20261003T122921Z-41233d5d/run.json`

Earlier failed attempts and the two seeded successful packets remain untouched. No parent/source/target live repository, AK, global installation, publication or verification.log writes occurred. This is NEW evidence, not adoption, historical packet recovery, or task closeout.

## Passing evidence — high confidence

- Exact archive `53af4392788656a8d9d11b188f3094365ae32746df45748048d61c2d14ac5b97` from `bbeebdfd1935afff65b8e8dcd1aa46753a229440`, tree `cb60d31393d292bab89cee5caa74e5dbef1ce9b8`; all archived bytes still unchanged.
- Original target lock and tooling lock remained byte-identical. Runtime versions and actual binary hashes are pinned/checked and recorded (Node 26.9.0, Bun 1.3.12, Linux x64).
- Cold official-only install succeeded with default frozen-lock integrity verification enabled and lifecycle scripts ignored. 217 unique locked target packages, 205 applicable packages; platform-mismatched optional dependencies skipped normally. All applicable pinned package identities were found in the newly downloaded cache; complete file digests and locked SHA-512 values retained. No previous cache or node_modules was copied.
- Original target was subsequently frozen-installed offline; tooling used its exact retained manifest/lock and local verified CLI tarball.
- Network was disabled for focused proofs/CLI. 17 tests passed, 42 assertions; manual content-bound witness current; mutation baseline pass/0; no stale witness support or error mutants.
- **176 analyzed sources / 60 LCOV entries / 25 selected mutants: 16 killed, 9 survived, 0 errors.** Exact explicit changed scope `src/core/runtime-config.ts`. Counts/outcomes match seeded replays; no scope reduction.
- Report/explain/plan/govern/authorize executed with the exact run id; no source/control-plane projection drift.
- Malformed local CLI digest and bad arity were rejected before allocation/network. Local no-network fixtures verified proxy rejection of unauthorized hosts/ports/methods, owned process-group cleanup, and sandbox parent death via SIGTERM. No proxy processes remain.

## Confirmed discrepancies / negative evidence

- **High confidence:** quality verdict **fail 19/100**, mutation score 0.64 below 0.80; 2 governance errors; maintainer merge authorization **deny**. CLI exit zero records successful evidence production, not approval. Survivors indicate residual test pressure, not necessarily nine non-equivalent production bugs.
- **High confidence, transport constraint:** archived lock has explicit npmmirror URLs. Bun 1.3.12 honors them despite --registry=npmjs.org. The direct cold attempt failed because our proxy refused the mirror; no mirror was contacted. This is not a registry-unavailable-pin claim.
- To satisfy official-only retrieval without altering archived target/tooling locks, the lean procedure generates a **separate, frozen, install-only endpoint projection**. Only mirror prefixes are changed to official npm URLs, while all package versions/keys/metadata/integrities are compared unchanged. This distinction is explicit in receipts and recipe docs. It is not an assertion that the projected fetch lock is byte-identical to the original. If a consumer forbids even that derived transport artifact, the stricter combination remains blocked; do not hide it.
- Initial helper had a cleanup defect (terminating bwrap monitor left its proxy child). Only verified task-owned children were stopped; final helper uses a dedicated process group, group termination and --die-with-parent. Final full cold replay plus local lifecycle checks passed. Receipts retain the failed experiments and the cleanup correction.
- An initial receipt checker incorrectly required HOME to remain empty after Bun generated its own transpile cache. That experimental recipe exited 2 despite completed quality artifacts; its receipt remains a failure. Final checks require initially empty sanitized HOME and inventory later generated files.

## Missing coverage

No full target suite/services/builds/e2e/perf were run. The same 17-case focused test does not cover malformed YAML/config-file types, missing-leaf symlink escapes, races, or partial config state after throws. Mutation selection is capped at 25. The CLI truncates internal per-mutant/baseline details; full internal transcripts are not invented.

## Untested risks / limits

Future npm availability, different-host ABI/runtime differences and whole-workflow interruption at every install/mutation/publication boundary remain untested. The SIGTERM fixture proves parent-death cleanup, not exhaustive interruption recovery. No historical Node 22 parity, adoption or historical identity claim.

Bun's verifier enforces locked tarball SHA-512 during the cold install; raw downloaded tarballs are not independently archived/rehashed by a second verifier. Cache-file digests and locked integrities are retained. Verbose HTTP URL logging is partial (first 64 observed GETs); proxy CONNECT logs restrict endpoints and all applicable packages are checked, but these are not a full HTTP transcript.

## Elapsed observations only

Final official fetch/install outer command: 7.109 s. Final fullscope check: 8.714 s. These are observed durations, not SLOs or historical comparisons.

## Reproduction

`git -C "$SOURCE_REPO" archive --format=tar bbeebdfd1935afff65b8e8dcd1aa46753a229440 > "$OWNED_INPUTS/source.tar"`

`TMPDIR="$HOME/owned-scratch" bash lean/replay.sh "$OWNED_INPUTS/source.tar" "$OWNED_INPUTS/ts-quality-0.7.0.tgz"`

Ensure TMPDIR exists/is owned/not /tmp; pinned runtime bytes and bwrap/Python/heavy-job are available. No 65 MB cache or 78 MB old packet is required. Dependencies are generated anew from official registry and need not be committed.
