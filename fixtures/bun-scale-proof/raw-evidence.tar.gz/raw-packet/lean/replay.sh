#!/usr/bin/env bash
# Small, cold-cache replay recipe. Exit 0 = evidence produced, NOT quality approval.
set -euo pipefail
RECIPE="$(cd -- "$(dirname -- "$0")" && pwd -P)"
[[ "$#" == 2 ]] || { echo 'Usage: replay.sh supplied-source.tar supplied-ts-quality-0.7.0.tgz' >&2; exit 2; }
: "${TMPDIR:?Set owned home-backed TMPDIR}"
[[ -d "$TMPDIR" && -O "$TMPDIR" ]] || { echo 'TMPDIR must be an existing owned directory' >&2; exit 2; }
case "$(realpath "$TMPDIR")" in /tmp|/tmp/*) echo 'Refusing /tmp scratch' >&2; exit 2;; esac
node "$RECIPE/verify-inputs.mjs" "$RECIPE" "$1" "$2"
R="$(mktemp -d "$TMPDIR/task6551-lean-cold-XXXXXXXX")"
printf 'cold_replay_root=%s\n' "$R"
mkdir -p "$R/inputs" "$R/target" "$R/tooling" "$R/registry-fetch" "$R/cache" "$R/home" "$R/tmp" "$R/logs" "$R/receipts" "$R/lean"
cp -r "$RECIPE/." "$R/lean/"
cp "$1" "$R/inputs/source.tar"
cp "$2" "$R/inputs/ts-quality-0.7.0.tgz"
tar -xf "$R/inputs/source.tar" -C "$R/target"
cp "$R/lean/tooling-package.json" "$R/tooling/package.json"
cp "$R/lean/tooling-bun.lock" "$R/tooling/bun.lock"
node -e 'const fs=require("fs"),r=process.argv[1];const c=fs.readdirSync(r+"/cache"),h=fs.readdirSync(r+"/home");if(c.length||h.length)process.exit(2);fs.writeFileSync(r+"/receipts/cold-start.json",JSON.stringify({cacheEntries:c,homeEntries:h,priorCacheCopied:false,priorNodeModulesCopied:false},null,2)+"\n");' "$R"
node "$R/lean/prepare-fetch.mjs" "$R"
run_heavy() {
  local label="$1"; shift
  AI_SOCIETY_SCRATCH_ROOT="$R/heavy-job" PYTHONDONTWRITEBYTECODE=1 heavy-job run --label "$label" --task 6551 -- "$@"
}
# Network only in frozen ignore-scripts installers, via registry.npmjs.org CONNECT allowlist.
# The fetch-project lock is a byte-reproducible transport projection only, not the target lock.
run_heavy task6551-lean-official-fetch node "$R/lean/command.mjs" "$R" official-fetch-frozen-install "$R/registry-fetch" install bun install --frozen-lockfile --ignore-scripts --backend=copyfile --cache-dir "$R/cache" --registry=https://registry.npmjs.org --verbose > "$R/logs/official-fetch-wrapper.log" 2>&1
# Original target lock installed unmodified with network disabled and newly retrieved bytes.
run_heavy task6551-lean-target node "$R/lean/command.mjs" "$R" target-original-frozen-install "$R/target" proof bun install --frozen-lockfile --ignore-scripts --backend=copyfile --cache-dir "$R/cache" --registry=https://registry.npmjs.org --verbose > "$R/logs/target-install-wrapper.log" 2>&1
run_heavy task6551-lean-tooling node "$R/lean/command.mjs" "$R" tooling-frozen-install "$R/tooling" install bun install --frozen-lockfile --ignore-scripts --backend=copyfile --cache-dir "$R/cache" --registry=https://registry.npmjs.org --verbose > "$R/logs/tooling-install-wrapper.log" 2>&1
cp -r "$R/lean/support/.ts-quality" "$R/target/"
cp "$R/lean/support/ts-quality.config.ts" "$R/target/"
CLI="$R/tooling/node_modules/ts-quality/dist/packages/ts-quality/src/cli.js"
node "$R/lean/command.mjs" "$R" cli-version "$R/target" proof node "$CLI" --version
node "$R/lean/command.mjs" "$R" focused-coverage "$R/target" proof bun test tests/runtime-config.test.ts --coverage --coverage-reporter=lcov --coverage-dir=.ts-quality/adoption/coverage
node "$R/lean/command.mjs" "$R" manual-witness "$R/target" proof node "$CLI" witness test --invariant runtime-config.path-containment --scenario escape-attempts-rejected --source-files src/core/runtime-config.ts --test-files tests/runtime-config.test.ts --out .ts-quality/witnesses/runtime-config-path-containment.json -- bun test tests/runtime-config.test.ts
RUNID="task6551-lean-cold-$(date -u +%Y%m%dT%H%M%SZ)-$(node -e "process.stdout.write(require('crypto').randomBytes(4).toString('hex'))")"
printf '%s\n' "$RUNID" > "$R/receipts/run-id.txt"
run_heavy task6551-lean-check node "$R/lean/command.mjs" "$R" fullscope-check "$R/target" proof node "$CLI" check --changed src/core/runtime-config.ts --run-id "$RUNID" > "$R/logs/check-wrapper.log" 2>&1
for command in report explain plan govern; do
  node "$R/lean/command.mjs" "$R" "projection-$command" "$R/target" proof node "$CLI" "$command" --run-id "$RUNID"
done
node "$R/lean/command.mjs" "$R" projection-report-json "$R/target" proof node "$CLI" report --run-id "$RUNID" --json
node "$R/lean/command.mjs" "$R" projection-authorize "$R/target" proof node "$CLI" authorize --run-id "$RUNID" --agent maintainer --action merge
node "$R/lean/capture.mjs" "$R"
printf 'raw_run=%s/target/.ts-quality/runs/%s/run.json\n' "$R" "$RUNID"
