import fs from 'node:fs'; import cp from 'node:child_process'; import crypto from 'node:crypto'; import path from 'node:path';
const [r,label,cwd,mode,...command]=process.argv.slice(2);
if(!['install','proof'].includes(mode))throw Error('mode must be install/proof');
if(mode==='install' && (command[0]!=='bun'||command[1]!=='install'||!command.includes('--frozen-lockfile')||!command.includes('--ignore-scripts')))throw Error('Network only allowed for frozen ignore-scripts installer');
const bin=name=>cp.execFileSync('/usr/bin/which',[name],{encoding:'utf8'}).trim();
const env={HOME:r+'/home',PATH:path.dirname(bin('bun'))+':'+path.dirname(bin('node'))+':/usr/bin:/bin',TMPDIR:r+'/tmp',BUN_INSTALL_CACHE_DIR:r+'/cache'};
let proxy=null;const portPath=r+'/receipts/'+label+'.proxy-port';const proxyLog=r+'/logs/'+label+'.proxy.jsonl';
const sandbox=argv=>['--die-with-parent','--ro-bind','/','/','--bind',r,r,'--proc','/proc','--dev','/dev',...argv];
if(mode==='install'){
 proxy=cp.spawn('/usr/bin/bwrap',sandbox(['env','-i',...Object.entries(env).map(([k,v])=>k+'='+v),'/usr/bin/python3',r+'/lean/registry-proxy.py',proxyLog,portPath]),{stdio:['ignore','ignore','inherit'],detached:true});
 for(let i=0;i<300&&!fs.existsSync(portPath);i++)await new Promise(res=>setTimeout(res,10));
 if(!fs.existsSync(portPath)){try{process.kill(-proxy.pid,'SIGTERM');}catch{}throw Error('Registry proxy did not start');}
 const url='http://127.0.0.1:'+fs.readFileSync(portPath,'utf8').trim();env.HTTPS_PROXY=url;env.HTTP_PROXY=url;env.ALL_PROXY=url;
}
const argv=[...(mode==='proof'?['--unshare-net']:[]),...sandbox(['--chdir',cwd,'env','-i',...Object.entries(env).map(([k,v])=>k+'='+v),...command])];
const startedAt=new Date().toISOString();const start=process.hrtime.bigint();let result;
try{result=cp.spawnSync('/usr/bin/bwrap',argv,{maxBuffer:128*1024*1024,timeout:600000,encoding:null});}
finally{if(proxy){try{process.kill(-proxy.pid,'SIGTERM');}catch{}if(proxy.exitCode===null)await new Promise(res=>{proxy.once('exit',res);setTimeout(res,2000);});}}
const elapsedMs=Number(process.hrtime.bigint()-start)/1e6;
fs.writeFileSync(r+'/logs/'+label+'.stdout',result.stdout??'');fs.writeFileSync(r+'/logs/'+label+'.stderr',result.stderr??'');
const receipt={label,mode,cwd,command,sandboxCommand:['/usr/bin/bwrap',...argv],environment:env,startedAt,endedAt:new Date().toISOString(),elapsedMs,exitCode:result.status,signal:result.signal,error:result.error?.message??null,stdoutSha256:crypto.createHash('sha256').update(result.stdout??'').digest('hex'),stderrSha256:crypto.createHash('sha256').update(result.stderr??'').digest('hex'),proxyLog:proxyLog};fs.writeFileSync(r+'/receipts/'+label+'.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({label,exitCode:result.status,elapsedMs,error:receipt.error}));process.exit(result.status??2);
