#!/usr/bin/env python3
"""Ephemeral CONNECT forwarder: allow only official npm registry HTTPS."""
import json, select, socket, socketserver, sys, threading
log_path, port_path = sys.argv[1:3]
lock = threading.Lock()
def record(row):
    with lock:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, sort_keys=True) + "\n")
class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline(8193).decode("ascii", "replace").strip()
        parts = line.split()
        if len(parts) != 3:
            return
        method, target, _ = parts
        while self.rfile.readline(8193) not in (b"\r\n", b"\n", b""):
            pass
        allowed = method == "CONNECT" and target.lower() == "registry.npmjs.org:443"
        record({"method": method, "target": target, "allowed": allowed})
        if not allowed:
            self.wfile.write(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
            return
        try:
            upstream = socket.create_connection(("registry.npmjs.org", 443), timeout=60)
            upstream.settimeout(None)
            self.wfile.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            self.wfile.flush()
            sockets = [self.connection, upstream]
            try:
                while True:
                    readable, _, _ = select.select(sockets, [], [], 120)
                    if not readable:
                        return
                    for source in readable:
                        data = source.recv(65536)
                        if not data:
                            return
                        (upstream if source is self.connection else self.connection).sendall(data)
            finally:
                upstream.close()
        except OSError as error:
            record({"target": target, "error": str(error)})
class Server(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = False
with Server(("127.0.0.1", 0), Handler) as server:
    with open(port_path, "w", encoding="ascii") as f:
        f.write(str(server.server_address[1]))
    server.serve_forever()
