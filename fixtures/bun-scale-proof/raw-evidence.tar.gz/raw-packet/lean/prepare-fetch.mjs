import fs from 'node:fs'; import crypto from 'node:crypto';
const r=process.argv[2];const source=fs.readFileSync(r+'/target/bun.lock','utf8');
const parse=text=>JSON.parse(text.replace(/,(\s*[}\]])/g,'$1'));
const original=parse(source);const projected=source.replaceAll('https://registry.npmmirror.com/','https://registry.npmjs.org/');const current=parse(projected);
for(const [key,entry] of Object.entries(original.packages)){
 const next=current.packages[key];if(JSON.stringify([entry[0],entry[2],entry[3]])!==JSON.stringify([next[0],next[2],next[3]]))throw Error('Version/metadata/integrity change '+key);
 if(typeof next[1]==='string'&&next[1]&&!next[1].startsWith('https://registry.npmjs.org/'))throw Error('Nonofficial URL '+next[1]);
 if(typeof entry[3]!=='string'||!entry[3].startsWith('sha512-'))throw Error('Missing locked integrity '+key);
}
fs.copyFileSync(r+'/target/package.json',r+'/registry-fetch/package.json');fs.writeFileSync(r+'/registry-fetch/bun.lock',projected);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
fs.writeFileSync(r+'/receipts/transport-projection.json',JSON.stringify({kind:'install-only endpoint projection, NOT replacement of archived target lock',sourceLockSha256:hash(source),projectionLockSha256:hash(projected),packageCount:Object.keys(original.packages).length,changedEndpointCount:(source.match(/https:\/\/registry\.npmmirror\.com\//g)||[]).length,preserved:'all locked versions, package keys, dependency metadata, integrity values and workspace manifest',network:'CONNECT allowlist registry.npmjs.org:443 only; nonofficial hosts are refused without contact',targetLockRewritten:false},null,2)+'\n');
