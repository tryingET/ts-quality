import fs from 'node:fs'; import crypto from 'node:crypto';import cp from 'node:child_process';
const [recipe,archive,cli]=process.argv.slice(2);const m=JSON.parse(fs.readFileSync(recipe+'/inputs.json'));const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');const expect=(p,d)=>{if(hash(p)!==d)throw Error('Checksum mismatch '+p);};
expect(archive,m.source.archiveSha256);expect(cli,m.cli.sha256);expect(recipe+'/tooling-package.json',m.smallInputs.toolingManifest);expect(recipe+'/tooling-bun.lock',m.locks.tooling);
for(const f of m.smallInputs.support)expect(recipe+'/support/'+f.path,f.sha256);
for(const name of ['node','bun']){const bin=cp.execFileSync('/usr/bin/which',[name],{encoding:'utf8'}).trim();expect(bin,m.runtime[name].sha256);const version=cp.execFileSync(bin,['--version'],{encoding:'utf8'}).trim();if(version!==m.runtime[name].version)throw Error('Version mismatch '+name);}
if(process.platform!==m.runtime.platform||process.arch!==m.runtime.arch)throw Error('Platform mismatch');console.log('All supplied archive/CLI/config/lock/runtime hashes match');
