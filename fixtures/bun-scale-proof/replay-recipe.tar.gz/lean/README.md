# #6551 lean cold-cache reconstruction

Tested recipe, not adoption or quality approval. No prior cache, node_modules, 65 MB seed, 78 MB packet, or current target tree is required. Preserve this small directory plus the supplied CLI tarball; reproduce the target archive from its exact Git commit.

## Required inputs

1. Source archive from commit `bbeebdfd1935afff65b8e8dcd1aa46753a229440`, tree `cb60d31393d292bab89cee5caa74e5dbef1ce9b8`:

`git -C "$SOURCE_REPO" archive --format=tar bbeebdfd1935afff65b8e8dcd1aa46753a229440 > "$OWNED_INPUTS/source.tar"`

SHA-256: `53af4392788656a8d9d11b188f3094365ae32746df45748048d61c2d14ac5b97`. This reads Git objects, not the dirty working tree. Do not fetch another commit or substitute a live copy.

2. Retained local ts-quality 0.7.0 tarball (~176 KB), SHA-256 `6da7db1de4ca272346677740f20f2ab6c7a125bd96e40d58a5c52af9b77334ae`. Do not substitute a same-version registry release or current-source build.
3. This directory's exact tooling manifest/lock, config/support, and helper files. `inputs.json` records hashes.
4. Linux x64, Node v26.9.0 and Bun 1.3.12 with the recorded binary SHA-256 values; bwrap, Python 3, and the installed heavy-job runner. Put matching runtime binaries on PATH; no global installation is performed.
5. Official npm registry HTTPS access during the frozen ignore-scripts installers.

## Execute

`TMPDIR="$HOME/owned-scratch" bash replay.sh "$OWNED_INPUTS/source.tar" "$OWNED_INPUTS/ts-quality-0.7.0.tgz"`

TMPDIR must already exist, be owned, and not resolve under /tmp. The script creates a fresh child directory, verifies empty HOME/cache, and copies only small recipe/data inputs plus the exact supplied archive and CLI tarball. It prints the new root, run id and raw run path. Existing source checkouts and prior successful/failed packets remain untouched. Exit 0 means reconstruction and evidence production completed, **not that the quality verdict passed**.

## Why the separate fetch project exists

**Observed:** Bun 1.3.12 does not override explicit `registry.npmmirror.com` tarball URLs in the archived lock with `--registry=https://registry.npmjs.org`. A direct cold install is rejected by the official-only proxy; this is not an unavailable-version assertion.

`prepare-fetch.mjs` writes a new install-only endpoint projection under `registry-fetch/`: only `https://registry.npmmirror.com/` prefixes become `https://registry.npmjs.org/`. Every locked version, integrity, package key, dependency metadata and workspace manifest is compared and retained. It does **not** replace or edit `target/bun.lock` or `tooling/bun.lock`. The projected lock is frozen for official retrieval; the original target lock is subsequently frozen-installed **offline** from those newly retrieved bytes. Projection bytes/hash and the original lock hash are retained in the actual receipt.

This is an explicit transport projection, not a claim that Bun rewrites the original lock or that the fetch lock is byte-identical to it. If even a separate endpoint-only fetch projection is forbidden by a consumer, official-only cold Bun installation of the unmodified mirror-bound archive remains blocked; do not silently weaken that constraint.

## Boundaries and evidence

- Network enabled only for frozen ignore-scripts fetch/tooling installs, via an ephemeral CONNECT proxy which forwards only `registry.npmjs.org:443`. No lifecycle scripts, dependency omissions, pin changes or global installs.
- All proof commands and original target installation use `bwrap --unshare-net`; host filesystem is read-only except the new owned root. Each command uses `env -i` and owned HOME/cache/TMPDIR. Bun may create its own transpile cache under this initially empty HOME; these newly generated files are inventoried, never borrowed.
- Proxy process groups are terminated after installation; `--die-with-parent` handles sandbox parent death. Owned-group cleanup and parent-death behavior have local no-network fixture evidence. Whole-workflow interruption at every stage is not exhaustively tested.
- Bun's frozen-lock integrity verifier remains enabled. Receipts retain all locked SHA-512 values, platform skips, applicable cached package identity checks, complete cache-file digests, command arrays/environments, logs and raw artifacts. Verbose GET URL snippets are not a complete HTTP transcript; proxy logs constrain transport endpoints, and TLS is forwarded without a substitute CA. No downloaded dependencies need be committed or retained as future inputs.
- Platform-mismatched optional packages are skipped normally: 217 unique locked packages; 205 applicable to this Linux x64 run. All applicable frozen package identities were found in the fresh cache.

## Verified actual cold outcomes

The final recipe bytes were run end-to-end in `/home/tryinget/.local/state/pi-quests/tmp/task6551-lean-cold-D7lynoEC`, run id `task6551-lean-cold-20261003T122921Z-41233d5d`. All locks remained unchanged; 17 focused tests passed; witness and mutation baseline passed; 176 source files, 60 LCOV entries, 25 mutants (16 killed, 9 survived, 0 errors); fail verdict 19/100; 2 governance errors; maintainer merge authorization deny. Counts and outcomes match the earlier seeded replays.

Main proof elapsed observations and all receipts are in the accompanying small raw packet. Raw run/witness bytes differ by time, path, id and runtime context; no historical Node 22 parity or historical packet identity is claimed.

## Coverage limits

The target proof remains only `tests/runtime-config.test.ts`; no full suite/services/builds or scope reduction. Malformed YAML/config-file types, missing-leaf symlink escape, path races and partial-state behavior remain outside that focused test. Nine surviving mutants are residual test pressure, not automatically nine non-equivalent production bugs. Complete internal per-mutant transcripts are not exposed by the shipped CLI. Registry availability at future replay time and different-host runtime/ABI conditions remain external risks.
